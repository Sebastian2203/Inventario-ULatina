﻿Imports System.Data.SqlClient
Public Class Form1
    Public connection As String = "workstation id=ULATINA-ASSETS.mssql.somee.com;packet size=4096;user id=CararaSoftware_SQLLogin_1;pwd=gilyiri9s6;data source=ULATINA-ASSETS.mssql.somee.com;persist security info=False;initial catalog=ULATINA-ASSETS"
    Dim adapter As SqlDataAdapter
    Dim dataTable As DataTable
    Dim iterator As Integer = 4


    Private Sub llenarcombo()
        For Each row As DataRow In dataTable.Rows
            CbxUser.Items.Add(row("Name"))
        Next
    End Sub

    Private Sub BtnLogin_Click(sender As Object, e As EventArgs) Handles BtnLogin.Click
        Dim password As String
        Dim user As Short

        user = CbxUser.SelectedIndex

        Dim fila As DataRow
        fila = dataTable.Rows(user)
        password = fila("password").ToString()

        If TbxPassword.Text = "" Then
            MessageBox.Show("Falta ingresar la contraseña")


        Else


            If TbxPassword.Text.Equals(password) Then

                MessageBox.Show("Bienvenido usuario : " + CbxUser.Text)

                PrincipalMenu.Visible = True
                Me.Hide()


            Else



                iterator = iterator - 1
                MessageBox.Show("la clave es incorrecta le quedan " + iterator.ToString + " intentos")


            End If


            If iterator = 0 Then
                MessageBox.Show("No quedan más intentos ")
                Me.Close()


            End If

        End If


    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        adapter = New SqlDataAdapter("select *from User_User", connection)
        dataTable = New DataTable
        adapter.Fill(dataTable)


        llenarcombo()
    End Sub

End Class
